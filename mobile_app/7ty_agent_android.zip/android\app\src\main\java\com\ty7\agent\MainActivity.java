package com.ty7.agent;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
